  import 'dart:io';
  import 'package:flutter/services.dart';
  import 'package:flutter/material.dart';
  import 'package:splash_screen_view/SplashScreenView.dart';
  import 'package:supabase_flutter/supabase_flutter.dart';
  
  
  
  import 'package:myapp/src/pages/connection/page.dart';
  import 'package:teta_cms/teta_cms.dart';

  ///NOTE:
  ///if you have an error while running <flutter run> 
  ///run <flutter pub upgrade> and than <flutter run --no-sound-null-safety>
  void main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    await TetaCMS.initialize(
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImxhbWJlcnR6Lm1hdGhpZXVAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsInByb2plY3RzIjpbMTM1NTU5LDEzNTU4NV0sImltYWdlIjoiaHR0cHM6Ly9saDMuZ29vZ2xldXNlcmNvbnRlbnQuY29tL2EtL0FPaDE0R2hJSUpTRFg0ckhzZUJlYUl2WGlOa2tka1BGcmFPVmJkN3pmNnlVPXM5Ni1jIiwibmFtZSI6Ik1hdGhpZXUgTGFtYmVydHoiLCJlbWl0dGVyIjoiVGV0YS1BdXRoIiwiaWF0IjoxNjU1NjY3NDEyLCJleHAiOjQ4MTE0Mjc0MTJ9.GFnlhRWqQSRs63Q3LONs7pXMbufFtwh5iJhOhim_T6o',
      prjId: 135585,
    );
    
      Supabase.initialize(
    url: 'https://lcvwfrngydgvgwmnhxdb.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxjdndmcm5neWRndmd3bW5oeGRiIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NTU2NDM0NjQsImV4cCI6MTk3MTIxOTQ2NH0.BUnwlJshGFce91FEUfDV1i7SwodtqLDhiW_Z_bsLQss',
  );
  
    
    
    runApp(MyApp());
  }
  class MyApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return MaterialApp(
        title: 'BFSG v1',
        home: SplashScreenView(
          navigateRoute: PageConnection(),
          duration: 2200,
          imageSize: 80,
          imageSrc: 'assets/teta-app.png',
          text: '',
          textType: TextType.NormalText,
          textStyle: TextStyle(
            fontSize: 30.0,
          ),
          backgroundColor: Colors.black,
        ),
      );
    }
  }
  