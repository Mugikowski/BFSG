import 'dart:ui';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:myapp/src/components/index.dart';
import 'package:supabase/supabase.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:myapp/auth/auth_state.dart';

import 'package:url_launcher/url_launcher_string.dart';
import 'package:auth_buttons/auth_buttons.dart';

import 'package:bouncing_widget/bouncing_widget.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:collection/collection.dart';
import 'package:myapp/src/pages/index.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:latlng/latlng.dart';
import 'package:badges/badges.dart';
import 'package:paged_vertical_calendar/paged_vertical_calendar.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:http/http.dart' as http;
import 'package:teta_cms/teta_cms.dart';
import 'package:webviewx/webviewx.dart';

class PageConnection extends StatefulWidget {
  const PageConnection({
    Key? key,
  }) : super(key: key);

  @override
  _StateConnection createState() => _StateConnection();
}

class _StateConnection extends AuthState<PageConnection>
    with SingleTickerProviderStateMixin {
  String email = '0';
  String password = '0';
  String status = '0';

  var datasets = <String, dynamic>{};
  int index = 0;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            margin: EdgeInsets.zero,
            padding: EdgeInsets.zero,
            width: double.maxFinite,
            decoration: const BoxDecoration(
              color: Color(0xFFFFFFFF),
              border: Border(
                left: BorderSide(
                    width: 0,
                    style: BorderStyle.none,
                    color: Color(0xFF000000)),
                top: BorderSide(
                    width: 0,
                    style: BorderStyle.none,
                    color: Color(0xFF000000)),
                right: BorderSide(
                    width: 0,
                    style: BorderStyle.none,
                    color: Color(0xFF000000)),
                bottom: BorderSide(
                    width: 0,
                    style: BorderStyle.none,
                    color: Color(0xFF000000)),
              ),
            ),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(
                        left: 24,
                        top: 400,
                        right: 24,
                        bottom: 8,
                      ),
                      width: double.maxFinite,
                      decoration: BoxDecoration(
                        color: const Color(0xFF838383),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                          bottomRight: Radius.circular(16),
                          bottomLeft: Radius.circular(16),
                        ),
                        border: null,
                      ),
                      child: TextField(
                        onChanged: (String value) async {
                          setState(() {
                            email = value;
                          });
                        },
                        onSubmitted: (String value) async {},
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          hintText: r'''E-Mail''',
                          contentPadding: const EdgeInsets.only(
                            left: 16,
                          ),
                        ),
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: const Color(0xFFFFFFFF),
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                        maxLines: 1,
                        minLines: 1,
                        maxLength: null,
                        obscureText: false,
                        showCursor: true,
                        autocorrect: false,
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(
                        left: 24,
                        right: 24,
                        bottom: 8,
                      ),
                      width: double.maxFinite,
                      decoration: BoxDecoration(
                        color: const Color(0xFF838383),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                          bottomRight: Radius.circular(16),
                          bottomLeft: Radius.circular(16),
                        ),
                        border: null,
                      ),
                      child: TextField(
                        onChanged: (String value) async {
                          setState(() {
                            password = value;
                          });
                        },
                        onSubmitted: (String value) async {},
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                              bottomRight: Radius.circular(16),
                              bottomLeft: Radius.circular(16),
                            ),
                          ),
                          hintText: r'''Mot de Pass''',
                          contentPadding: const EdgeInsets.only(
                            left: 16,
                          ),
                        ),
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                            color: const Color(0xFFFFFFFF),
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            fontStyle: FontStyle.normal,
                            decoration: TextDecoration.none,
                          ),
                        ),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                        maxLines: 1,
                        minLines: 1,
                        maxLength: null,
                        obscureText: false,
                        showCursor: true,
                        autocorrect: false,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 24,
                        top: 30,
                        right: 24,
                      ),
                      child: GestureDetector(
                        onTap: () async {
                          if (email != null && password != null) {
                            setState(() {
                              status = 'Loading';
                            });
                            final response = await Supabase.instance.client.auth
                                .signIn(email: email, password: password);
                            if (response.error != null ||
                                response.user == null) {
                              setState(() {
                                status = 'Failed';
                              });
                            } else {
                              setState(() {
                                status = 'Success';
                              });
                            }
                          }
                        },
                        onLongPress: () async {},
                        child: Container(
                            width: double.maxFinite,
                            height: 48,
                            decoration: BoxDecoration(
                              color: const Color(0xFF3285FF),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(16),
                                topRight: Radius.circular(16),
                                bottomRight: Radius.circular(16),
                                bottomLeft: Radius.circular(16),
                              ),
                              border: null,
                            ),
                            child: Center(
                              child: Text(
                                'Connection',
                                style: GoogleFonts.poppins(
                                  textStyle: TextStyle(
                                    color: const Color(0xFFFFFFFF),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16,
                                    fontStyle: FontStyle.normal,
                                    decoration: TextDecoration.none,
                                  ),
                                ),
                                textAlign: TextAlign.center,
                                textDirection: TextDirection.ltr,
                              ),
                            )),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 24,
                        top: 10,
                        right: 24,
                      ),
                      child: GestureDetector(
                        onTap: () async {
                          if (email != null && password != null) {
                            setState(() {
                              status = 'Loading';
                            });
                            final response = await Supabase.instance.client.auth
                                .signUp(email, password);
                            if (response.error != null) {
                              setState(() {
                                status = 'Failed';
                              });
                            } else {
                              setState(() {
                                status = 'Success';
                              });
                            }
                          }
                        },
                        onLongPress: () async {},
                        child: Container(
                            width: double.maxFinite,
                            height: 48,
                            decoration: BoxDecoration(
                              color: const Color(0xFF3285FF),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(16),
                                topRight: Radius.circular(16),
                                bottomRight: Radius.circular(16),
                                bottomLeft: Radius.circular(16),
                              ),
                              border: null,
                            ),
                            child: Center(
                              child: Text(
                                'Inscription Nouveaux membres',
                                style: GoogleFonts.poppins(
                                  textStyle: TextStyle(
                                    color: const Color(0xFFFFFFFF),
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16,
                                    fontStyle: FontStyle.normal,
                                    decoration: TextDecoration.none,
                                  ),
                                ),
                                textAlign: TextAlign.center,
                                textDirection: TextDirection.ltr,
                              ),
                            )),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 5,
                        top: 60,
                      ),
                      child: Text(r'''Bienvenue sur  l'application du BFSG''',
                          style: GoogleFonts.aleo(
                            textStyle: TextStyle(
                              color: const Color(0xFF3285FF),
                              fontWeight: FontWeight.w600,
                              fontSize: 40,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                          maxLines: 3),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 85,
                      ),
                      child: Image.network(
                        r'''https://lcvwfrngydgvgwmnhxdb.supabase.co/storage/v1/object/public/public/BFSG v1/assets/Logo_officiel_BFSG.png''',
                        height: 150,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 70,
                    top: 690,
                  ),
                  child: TextButton(
                    onPressed: () async {
                      if (await canLaunchUrlString(
                          '''https://www.instagram.com/basketflersstgeorges/?hl=fr''')) {
                        await launchUrlString(
                          '''https://www.instagram.com/basketflersstgeorges/?hl=fr''',
                          mode: LaunchMode.inAppWebView,
                        );
                      }
                    },
                    onLongPress: () async {},
                    child: Image.network(
                      r'''https://lcvwfrngydgvgwmnhxdb.supabase.co/storage/v1/object/public/public/BFSG v1/assets/640px-Instagram_icon.png''',
                      height: 70,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 250,
                    top: 690,
                  ),
                  child: TextButton(
                    onPressed: () async {
                      if (await canLaunchUrlString(
                          '''https://www.facebook.com/bfsgd''')) {
                        await launchUrlString(
                          '''https://www.facebook.com/bfsgd''',
                          mode: LaunchMode.inAppWebView,
                        );
                      }
                    },
                    onLongPress: () async {},
                    child: Image.network(
                      r'''https://lcvwfrngydgvgwmnhxdb.supabase.co/storage/v1/object/public/public/BFSG v1/assets/Facebook_f_logo_(2019).svg.png''',
                      height: 70,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
